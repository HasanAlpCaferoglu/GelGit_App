import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    
    request_body = event['body-json']
    
    username = request_body['username']
    email = request_body['email']
    userType = request_body['userType']
    loggedin = request_body['loggedin']
    userid = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        user_id = int(cursor.fetchone()[0])
    
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }
        
    if not('userid' in session and 'loggedin' in session and session['userType'] == 'admin'):
        message = 'You are not authorized!'
        return {
        'statusCode': 400,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
        }
    }
        
    with conn.cursor() as cursor:
        # get all coupons
        queryGetCoupons = """
        SELECT *
        FROM Sale_Coupon
        """
        cursor.execute(queryGetCoupons)
        allCoupons = cursor.fetchall()
        
        print("allCoupons from sql: ", allCoupons) 
        coupons_list = []
        for coupon in allCoupons:
            object = {
                'coupon_id' : coupon[0],
                'coupon_name' : coupon[1],
                'sale_rate' : coupon[2],
                'expiration_date' : coupon[3].strftime("%m/%d/%Y"),
                'generation_date' : coupon[4].strftime("%m/%d/%Y"),
                'status' : coupon[5],
            }
            coupons_list.append(object)
        print("Coupons", coupons_list)
        message = 'Coupons are successfully obtained.'
        
    conn.commit()
    
    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
            'coupons' : coupons_list,
        }
    }

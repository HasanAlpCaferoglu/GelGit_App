import json
import sys
import logging
import pymysql
import os
from datetime import datetime

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    request_body = event['body-json']
    loggedin = request_body['loggedin']
    userType = request_body['userType']
    companyId = event["params"]["path"]["company_id"]
    
    username = request_body['username']
    email = request_body['email']
    userid = None
    
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])
    
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }
    if not('userid' in session and 'loggedin' in session and session['userType'] == 'admin'):
        message = 'Session was not valid, please log in!'
        return {
            "statusCode" : 400,
            "message" : message
        }
    with conn.cursor() as cursor:
        message = None

        # check the company
        queryGetCompany = """
        SELECT company_name
        FROM Company
        WHERE id = %s
        """
        cursor.execute(queryGetCompany, (companyId,))
        companyInfo = cursor.fetchone()
        
        if companyInfo:
            queryValidate = """
            UPDATE Company SET validator_id = %s, validation_date = %s WHERE id = %s
            """
            current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute(queryValidate, (session['userid'], current_date,companyId))
            cursor.connection.commit()
            message = 'Company ' + companyInfo[0] + ' is validated.'

    conn.commit()

    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
        }
    }

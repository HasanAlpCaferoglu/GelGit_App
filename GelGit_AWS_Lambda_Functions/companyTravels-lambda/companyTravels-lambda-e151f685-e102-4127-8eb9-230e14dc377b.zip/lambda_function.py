import json
import sys
import logging
import pymysql
import os
from datetime import datetime


"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    
    print("Event: ", event)
    request_body = event['body-json']
    loggedin = request_body['loggedin']
    userType = request_body['userType']
    username = request_body['username']
    email = request_body['email']

    userid = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])
    
    sort_type = None
    upcomingOrPast = 'upcoming'
    travelDetailList = []
    company_travels = []
    
    
    request_type = event["context"]["http-method"]
    request_params = event["params"]
    # get info from event
    
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }
    
    # Check session
    if not('userid' in session and 'loggedin' in session and \
    ('userType' in session and session['userType'] == 'company') or ('userType' in session and session['userType'] == 'admin')):
        statusCode = 400
        message = "Session is not valid!"
        return {
            'statusCode': statusCode,  # Customizing the status code
            'body': {
                'message': message,  # Including custom message in the response body
            }
        }
        
    with conn.cursor() as cursor:

        if session['userType'] == "company":
            companyId = session['userid']

        if session['userType'] =='admin':
            companyId = int(event["params"]["path"]["company_id"])
       
        # initial values
        sort_type = 'depart_time'
        sort_in = 'earliest_to_latest'
        if 'sort_type' in request_body:
            sort_in = request_body['sort_type']
            print("sort_in: ", sort_in)

        if sort_in == 'earliest_to_latest':
            sort_type = 'depart_time ASC'
        elif sort_in == 'latest_to_earliest':
            sort_type = 'depart_time DESC'
        elif sort_in == 'price_low_to_high':
            sort_type = 'price ASC'
        elif sort_in == 'price_high_to_low':
            sort_type = 'price DESC'

        # initial values
        upcomingOrPast = 'upcoming'
        if 'upcomingOrPast' in request_body:
            upcomingOrPast = request_body['upcomingOrPast']
            
        if upcomingOrPast == 'upcoming':
            #get upcoming travels belongs to this company and list
            query = """
            SELECT *
            FROM companies_travels_detail_view
            WHERE  company_id = %s AND depart_time > %s
            ORDER BY {}
            """.format(sort_type)

            cursor.execute(query, (companyId, datetime.now()))
            travelDetailList = cursor.fetchall()
        elif upcomingOrPast == 'past':
            #get past travels belongs to the company and list
            query = """
            SELECT *
            FROM companies_travels_detail_view
            WHERE company_id = %s AND depart_time < %s
            ORDER BY {}
            """.format(sort_type)
            cursor.execute(query, (companyId, datetime.now()))
            travelDetailList = cursor.fetchall()
        
        conn.commit()
    conn.commit()
    
    company_travels = []
    for travel in travelDetailList:
        object = {
            "company_id" : travel[0],
            "company_name" : travel[1],
            "travel_id" : travel[2],
            "departure_time" : travel[3].strftime("%m/%d/%Y, %H:%M:%S"),
            "arrival_time" : travel[4].strftime("%m/%d/%Y, %H:%M:%S"),
            "price" : travel[5],
            "business_price" : travel[6],
            "departure_terminal" : travel[7],
            "departure_city" : travel[8],
            "arrival_terminal" : travel[9],
            "arrival_city" : travel[10],
            "vehicle_model" : travel[11],
            "vehicle_type" : travel[12]
            }
        company_travels.append(object)
        
    print("company_travels: ", company_travels)
    message = "Company travels are succesfully fetched."

    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message' : message,
            'travels_list' : company_travels,
        }
    }

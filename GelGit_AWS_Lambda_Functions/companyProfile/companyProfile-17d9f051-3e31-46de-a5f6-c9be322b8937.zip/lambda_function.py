import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    data = event
    print("event: ", event)
    print("context: ", context)
    body_json = event["body-json"]
    #user_id = body_json["userid"]
    #login_info = body_json["loggedin"]
    #user_type = body_json["userType"]
    
    username = body_json['username']
    email = body_json['email']
    user_type = body_json['userType']
    login_info = body_json['loggedin']
    user_id = None
    
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        user_id = int(cursor.fetchone()[0])
    
    
    session = {
        'userid' : user_id,
        'loggedin' : login_info,
        'userType' : user_type
    }
 
    message = '' # set message
    
    if not('userid' in session and 'loggedin' in session and \
    ('userType' in session and session['userType'] == 'company') or ('userType' in session and session['userType'] == 'admin')):
        message = "Session info is not found."
        return {
            'statusCode': 400,  # Customizing the status code
            'body': {
            'message': message,  # Including custom message in the response body
            }
        }
    # if there is no problem with session and users then get the company info
    with conn.cursor() as cursor:
        query = """
        SELECT id, email, phone, company_name, website, foundation_date, about
        FROM User U NATURAL JOIN Company C
        WHERE U.id = %s AND U.active = TRUE
        """
        cursor.execute(query, (user_id,))
        companyInfo = cursor.fetchone()
        companyProfile = {
            "user_id": companyInfo[0],
            "company_email": companyInfo[1],
            "company_phone": companyInfo[2],
            "company_name": companyInfo[3],
            "company_website": companyInfo[4],
            "company_foundation_date": companyInfo[5].isoformat(),
            "company_about": companyInfo[6]
        }
        logger.info(message)
    conn.commit()


    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
            'companyProfile': companyProfile,  # Including email for reference
        }
    }

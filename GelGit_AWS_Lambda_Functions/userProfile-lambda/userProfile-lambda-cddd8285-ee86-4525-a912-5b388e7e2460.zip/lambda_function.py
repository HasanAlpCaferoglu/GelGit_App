import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    
    data = event
    print("event: ", event)
    print("context: ", context)
    body_json = event["body-json"]
    username = body_json['username']
    email = body_json['email']
    user_type = body_json['userType']
    login_info = body_json['loggedin']
    user_id = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        user_id = int(cursor.fetchone()[0])
    
    session = {
        'userid' : user_id,
        'loggedin' : login_info,
        'userType' : user_type
    }

    # some example SQL commands
    with conn.cursor() as cursor:

        if not('userid' in session and 'loggedin' in session):
            message = "Session info is not found."
            return {
                'statusCode': 400,  # Customizing the status code
                'body': {
                'message': message,  # Including custom message in the response body
                #'session_info': session_info
                }
            }
        user_id = session['userid']
        
        #get user information
        query = """
        SELECT id, email, phone, TCK, name, surname, age, balance
        FROM User U NATURAL JOIN Traveler T
        WHERE U.id = %s AND U.active = TRUE
        """
        cursor.execute(query, (user_id,))
        userProfileTuple = cursor.fetchone()
        
        if userProfileTuple:
            message = "User profile information obtained."
        else:
            message = "Couldn't get user profile information!"
            return {
                'statusCode': 404,
                'body': {
                    "message": message
                }
            }
            
        userProfileInfo = {
            "user_id": userProfileTuple[0],
            "user_email": userProfileTuple[1],
            "user_phone": userProfileTuple[2],
            "user_TCK": userProfileTuple[3],
            "user_name": userProfileTuple[4],
            "user_surname": userProfileTuple[5],
            "user_age": userProfileTuple[6],
            "user_balance": userProfileTuple[7],
        } 
        
        logger.info(message)
        
    
    conn.commit()

    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
            'userProfileInfo' : userProfileInfo
        }
    }

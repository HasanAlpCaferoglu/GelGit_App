import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")

def validate_seat_formation(seat_formation):
    seat_numbers = seat_formation.split('-')
    if len(seat_numbers) < 2 or len(seat_numbers) > 4:
        return False
    for seat in seat_numbers:
        if not seat.isdigit():
            return False
    if seat_formation.endswith('-'):
        return False
    return True
    
def lambda_handler(event, context):
 
    request_type = event["context"]["http-method"]
    body_json = event["body-json"]

    username = body_json['username']
    email = body_json['email']
    user_type = body_json['userType']
    login_info = body_json['loggedin']
    user_id = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        user_id = int(cursor.fetchone()[0])
    
    session = {
        'userid' : user_id,
        'loggedin' : login_info,
        'userType' : user_type
    }

    if not('userid' in session and 'loggedin' in session and session['userType'] == 'admin'):
        message = 'Session is not valid, please log in!'
        return {
            "statusCode" : 400,
            "body": {
                "message" : message
            }
        }
    with conn.cursor() as cursor:
        message = None

        if request_type == 'POST':
            if 'vehicle_type' in body_json and body_json['vehicle_type'] and \
            'vehicle_seat_formation' in body_json and body_json['vehicle_seat_formation'] and \
            'vehicle_num_of_seats' in body_json and body_json['vehicle_num_of_seats'] and \
            'vehicle_business_rows' in body_json and body_json['vehicle_business_rows'] and \
            'vehicle_model' in body_json and body_json['vehicle_model'] :
                
                vehicle_type = body_json['vehicle_type']
                vehicle_seat_formation = body_json['vehicle_seat_formation']
                vehicle_num_of_seats = body_json['vehicle_num_of_seats']
                vehicle_business_rows = body_json['vehicle_business_rows']
                vehicle_model = body_json['vehicle_model']

                seatNumList = vehicle_seat_formation.strip().split('-')
                numSeatsInRow = sum(int(seat) for seat in seatNumList if seat != '')

                # check if the given seat formation is in the correct format
                if not validate_seat_formation(vehicle_seat_formation):
                    message = "Invalid format for seat formation "
                elif int(vehicle_num_of_seats) % numSeatsInRow != 0:
                    # check if the total seat number matches is divisable by seat number in a row
                    message = "The total number of seats in the vehicle is not divisible by number of seats in a row!"
                elif int(vehicle_business_rows) > (int(vehicle_num_of_seats) / numSeatsInRow):
                    # check if the business row is equal or smaller than the total row
                    message = "Number of rows for business class cannot be larger than the number of rows the vehicle have!"
                else:    
                    # check if there is such vehicle type which all properties are some with given values
                    queryFindVehicle = """
                    SELECT *
                    FROM Vehicle_Type
                    WHERE model = %s AND type = %s AND seat_formation = %s AND num_of_seats = %s AND business_rows = %s
                    """
                    cursor.execute(queryFindVehicle, (vehicle_model, vehicle_type, vehicle_seat_formation, vehicle_num_of_seats, vehicle_business_rows))
                    existingVehicleType = cursor.fetchone()
                    if existingVehicleType:
                        message = 'There is already an existing vehicle type that has the same properties'
                        return {
                            "statusCode" : 400,
                            "body": {
                                "message" : message
                            }
                        }
                    else:
                        # create the vehicle type
                        queryInsertVehicle = """
                        INSERT INTO Vehicle_Type (id, model, type, seat_formation, num_of_seats, business_rows)
                        VALUES (NULL, %s, %s, %s, %s, %s)
                        """
                        cursor.execute(queryInsertVehicle, (vehicle_model, vehicle_type, vehicle_seat_formation, vehicle_num_of_seats, vehicle_business_rows))
                        cursor.connection.commit()
                        message = "New vehicle Type successfully added!"
                        
            else:
                message = 'Please fill the form!'
                return {
                    "statusCode" : 400,
                    "body": {
                        "message" : message
                    }
                }

    conn.commit()
    

    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
            'some_other_data': 'value',  # Including additional data
        }
    }

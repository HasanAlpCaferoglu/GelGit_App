import json
import sys
import logging
import pymysql
import os
from datetime import datetime
""" DONE (session hardcoded)"""

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    # TODO implement
    print("Event: ", event)
    print("Context: ", context)
    
    # userid = request_body['userid']
    # loggedin = request_body['loggedin']
    # userType = request_body['userType']
    
    request_body = event['body-json']
    
    travel_date = request_body['travelDate']
    departure_terminal = request_body['departureTerminal']
    arrival_terminal = request_body['arrivalTerminal']
    travel_type = request_body['travelType']
    upcomingOrPast = request_body['upcomingOrPast']

    username = request_body['username']
    email = request_body['email']
    userType = request_body['userType']
    loggedin = request_body['loggedin']
    userid = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])
    
    

    request_type = event["context"]["http-method"]
    request_params = event["params"]
    # get info from event
    
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }

    message = ''
    if not('userid' in session and 'loggedin' in session and 'userType' in session and session['userType'] == 'traveler'):
        message = "Session info is not found."
        return {
            'statusCode': 400,  # Customizing the status code
            'body': {
            'message': message,  # Including custom message in the response body
            }
        }
        
    user_id = session['userid'] #session.get('userid')
    
    ######## RECONSIDER THIS comentAreaOnAPNR ######
    # commentAreaOnAPNR = None
    # if request_type == 'GET' and 'commentAreaOnAPNR' in request_params:
    #     commentAreaOnAPNR = request_params['commentAreaOnAPNR']

    ######## RECONSIDER THIS upcomingOrPast ######
    # upcomingOrPast = 'upcoming'
    # if request_type == 'GET' and 'upcomingOrPast' in request_params:
    #     upcomingOrPast = request_params['upcomingOrPast']
    
    with conn.cursor() as cursor:
        # Fetch all terminals' ids
        cursor.execute("SELECT terminal_id, city FROM Terminal")
        terminals = cursor.fetchall()
        
        # Fetch the id and type of the vehicle types 
        cursor.execute("SELECT id, type FROM Vehicle_Type")
        vehicles = cursor.fetchall()
    
        # Filter and remove duplicates from terminals
        departure_terminals = []
        arrival_terminals = []
        print("Terminals: ", terminals)
        for terminal in terminals:
            if terminal[1] not in [t[1] for t in departure_terminals]:
                departure_terminals.append(terminal)
            if terminal[1] not in [t[1] for t in arrival_terminals]:
                arrival_terminals.append(terminal)
            
        # Filter and remove duplicates from vehicle types
        vehicle_types = []
        print("Vehicles: ", vehicles)
        for vehicle_type in vehicles:
            if vehicle_type[1] not in [v[1] for v in vehicle_types]:
                vehicle_types.append(vehicle_type)
                
                
        # Retrieve filter values from the request arguments
        if travel_date == "":
            travel_date = None
        
        if departure_terminal == "":
            departure_terminal = None
       
        if arrival_terminal == "":
            arrival_terminal = None
        
        if travel_type == "":
            travel_type = None

        print("timemem:", type(travel_date))
        # Initialize the WHERE clause of the query
        where_clause = 'WHERE Booking.traveler_id = %s'
        query_params = [user_id]
        
        # Add conditions to the WHERE clause based on the filter values
        if travel_date:
            where_clause += ' AND DATE(Travel.depart_time) = %s'
            query_params.append(travel_date)
        if departure_terminal:
            where_clause += ' AND Travel.departure_terminal_id = %s'
            query_params.append(departure_terminal)
        if arrival_terminal:
            where_clause += ' AND Travel.arrival_terminal_id = %s'
            query_params.append(arrival_terminal)
        if travel_type:
            where_clause += ' AND Travel.vehicle_type_id = %s'
            query_params.append(travel_type)
    
        query = """
        SELECT Travel.travel_id, Booking.PNR, Booking.seat_number, Travel.depart_time,  Travel.arrive_time, Terminal.name AS departure_terminal_name, Terminal2.name AS arrival_terminal_name, Company.company_name
        FROM Booking
        JOIN Travel ON Booking.travel_id = Travel.travel_id
        JOIN Terminal ON Travel.departure_terminal_id = Terminal.terminal_id
        JOIN Terminal AS Terminal2 ON Travel.arrival_terminal_id = Terminal2.terminal_id
        JOIN Company ON Travel.travel_company_id = Company.id
        {}
        AND Travel.depart_time {} %s
        ORDER BY Travel.depart_time {}
        """

        if upcomingOrPast == 'past':
            comparison_operator = '<'
            order_by = 'DESC'
        else:
            comparison_operator = '>'
            order_by = 'ASC'
        
        print("datetimenowtype: ", type(datetime.now().strftime("%Y-%m-%d")))
        print("datetime: ", datetime.now().strftime("%Y-%m-%d"))
        formatted_query = query.format(where_clause, comparison_operator, order_by)
        cursor.execute(formatted_query, tuple(query_params + [datetime.now().strftime("%Y-%m-%d")]))
        user_travels = cursor.fetchall()

        ######## RECONSIDER THIS upcomingOrPast ######
        # currentRating = '1'
        # if request_type == 'GET' and 'rating' in request_params:
        #     currentRating = request_params['rating']

        query_reserved = """
        SELECT Reserved.PNR
        FROM Reserved
        JOIN Booking ON Reserved.PNR = Booking.PNR
        WHERE Booking.traveler_id = %s
        AND Reserved.PNR = Booking.PNR
        """
        cursor.execute(query_reserved, (user_id,))
        user_reserved_travels = cursor.fetchall()
        
        user_travels_list = [list(x) for x in user_travels]
        for row in user_travels_list:
            row[3] = row[3].isoformat()
            row[4] = row[4].isoformat()
        
        print("qmdw", user_travels_list)
               
        ## Note that we don't care the reserved travel list
        reserved_travels_pnr = [row[0] for row in user_reserved_travels]
        print("RESERVED TRAVELS: ", reserved_travels_pnr)

        user_purchased_travels = []
        for row in user_travels_list:
            if row[1] not in reserved_travels_pnr:
                object = {
                "travel_id": row[0],
                "PNR": row[1],
                "seat_number": row[2],
                "depart_time": row[3],
                "arrive_time": row[4],
                "departure_terminal_name": row[5],
                "arrival_terminal_name": row[6],
                "company_name": row[7]
                }
                user_purchased_travels.append(object) 
                
        print("USER TRAVELS: ", user_travels_list)
        print("USER PURCHASED TRAVELS: ", user_purchased_travels)
        message = "Successful!"
        logger.info(message)
    
    conn.commit()
    
    

    return {
        'statusCode': 200,  # Customizing the status code
        'body':{
            'message': message,  # Including custom message in the response body
            'user_purchased_travels' : user_purchased_travels,
            'user_id' : user_id,
            'upcomingOrPast' : upcomingOrPast,
            'reserved_travels_pnr' : reserved_travels_pnr,
            'departure_terminals' : departure_terminals,
            'arrival_terminals' : arrival_terminals,
            'vehicle_types' : vehicle_types,
            # 'commentAreaOnAPNR' : commentAreaOnAPNR,
            # 'currentRating' : currentRating,
        }
    }

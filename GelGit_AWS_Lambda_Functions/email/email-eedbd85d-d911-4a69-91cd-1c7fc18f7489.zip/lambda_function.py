import json
import boto3

def lambda_handler(event, context):
    print("event: ", event)
    body_json = event['body-json'] 
    username = body_json['username']
    email = body_json['email']
    user_type = body_json['userType']
    login_info = body_json['loggedin']
    seat_no = body_json["seat_number"]
    company_name = body_json["company_name"]
    pnr = body_json["pnr"]
    dep_terminal = body_json["departure_terminal"]
    arr_terminal = body_json["arrival_terminal"]
    price = body_json["price"]
    
    client = boto3.client("ses")
    
    subject = 'GelgitApp Purchase'

    # Specify the HTML body
    html_body = """
        <html>
        <head></head>
        <body>
            <h2>Ticket Details</h2>
            <h4>PNR</h4><p>{pnr}</p>
            <h4>Seat Number</h4><p>{seat_no}</p>
            <h4>Departure Termina</h4><p>{dep_terminal}</p>
            <h4>Arrival Terminal</h4><p>{arr_terminal}</p>
            <h4>Travel Company</h4><p>{company_name}</p>
        </body>
        </html>
    """.format(pnr=pnr, seat_no=seat_no, dep_terminal=dep_terminal, arr_terminal=arr_terminal, company_name=company_name)
    
    # Send the email
    response = client.send_email(
        Source="gelgitapp@gmail.com",
        Destination={'ToAddresses': [email]},
        Message={
            'Subject': {'Data': subject},
            'Body': {'Html': {'Data': html_body}}
        }
    )
    
    
    #message = event['message']
    #message = {"Subject" : {"Data" : "GelgitApp"}, "Body" : {"Html": html}}
    #response = client.send_email(Source="gelgitapp@gmail.com", Destination={"ToAddresses" : [email]}, Message=message)
    
    return response
import json
import sys
import logging
import pymysql
import os
from datetime import datetime

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    print("EVENT: ", event)
    request_type = event["context"]["http-method"]
    request_body = event['body-json']
    userid = None
    loggedin = request_body['loggedin']
    userType = request_body['userType']
    username = request_body['username']
    email = request_body['email']
    
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])
     
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }
    

    if not('userid' in session and 'loggedin' in session):
        message = 'Session was not valid, please log in!'
        return {
            "statusCode" : 400,
            "message" : message
        }
            
    sort_type = 'C.id ASC'
    sort_in = 'sort_by_name'
    filter_in = 'all'
    filter_type = 'all'
    filterClause = ''
    search_clause = ''
    print("body: ",event)
    if request_type == 'GET' and 'sort_type' in request_body or 'filter_type' in request_body or 'search_word' in request_body:
        sort_in = request_body['sort_type']
        if sort_in == 'sort_by_name' or sort_in == "":
            sort_type = 'C.company_name'
        elif sort_in == 'validation_date_earliest_to_latest':
            sort_type = ' C.validation_date ASC'
        elif sort_in == 'validation_date_latest_to_earliest':
            sort_type = ' C.validation_date DESC'
        elif sort_in == 'foundation_date_earliest_to_latest':
            sort_type = 'C.foundation_date ASC'
        elif sort_in == 'foundation_date_latest_to_earliest':
            sort_type = 'C.foundation_date DESC'
        elif sort_in == 'sort_by_id':
            sort_type = 'C.id ASC'
        else:
            sort_type = 'C.id ASC'

        filter_in = request_body['filter_type']
        if filter_in == 'validated':
            filter_type = 'validated'
            filterClause = 'AND C.validation_date IS NOT NULL'
        elif filter_in == 'unvalidated':
            filter_type = 'unvalidated'
            filterClause = 'AND C.validation_date IS NULL'
        elif filter_in == 'active':
            filter_type = 'active'
            filterClause = 'AND U.active = TRUE'
        elif filter_in == 'inactive':
            filter_type = 'inactive'
            filterClause = 'AND U.active = FALSE'
        else:
            filter_type = 'all'
            filterClause = ''

        search_word = request_body['search_word']
        if search_word:
            search_clause = 'AND C.company_name LIKE "%' + search_word + '%"'


    with conn.cursor() as cursor:
        
        queryCompanies = """
        SELECT
        C.id,
        C.company_name,
        C.website,
        C.foundation_date,
        C.about,
        C.validation_date,
        U.email,
        U.phone,
        U.active,
        A.username as admin_username
        FROM Company C
        NATURAL JOIN User U
        LEFT JOIN Administrator A ON A.id = C.validator_id
        WHERE TRUE {whereClause} {search_clause}
        ORDER BY {sortClause}
        """.format(whereClause = filterClause, search_clause=search_clause, sortClause = sort_type)
        cursor.execute(queryCompanies)
        allCompanies = cursor.fetchall()
        print("All companies: ", allCompanies)
        print("Sort Type: ", sort_in)
        print("Filter Type: ", filter_in)
    conn.commit()
    
    companies_list = []
    for company in allCompanies:
        object = {
            "company_id" : company[0],
            "company_name" : company[1],
            "company_website" : company[2],
            "foundation_date" : company[3].strftime("%m/%d/%Y") if company[3] and type(company[3]) != str else company[3],
            "about_company" : company[4],
            "validation_date" : company[5].strftime("%m/%d/%Y, %H:%M:%S") if company[5] and type(company[5]) != str else company[5],
            "company_email" : company[6],
            "company_phone" : company[7],
            "is_active" : company[8],
            "admin_username": company[9],
        }
        companies_list.append(object)
    message = "Companies!"
    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
            'companies' : companies_list,
            'sort_type' : sort_in,
            'filter_type' : filter_in
        }
    }

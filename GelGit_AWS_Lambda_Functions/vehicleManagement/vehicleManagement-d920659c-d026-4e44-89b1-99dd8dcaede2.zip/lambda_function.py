import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    request_body = event['body-json']
    userid = None
    loggedin = request_body['loggedin']
    userType = request_body['userType']
    username = request_body['username']
    email = request_body['email']
    
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])
    
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }

    if not('userid' in session and 'loggedin' in session and session['userType'] == 'admin'):
        message = "You are not authorized!"
        return {
            "statusCode" : 400,
            "message" : message
        }
        
    with conn.cursor() as cursor:
        message = None

        # get all vehicles
        queryGetVehicles = """
        SELECT *
        FROM Vehicle_Type
        """
        cursor.execute(queryGetVehicles)
        allVehicles = cursor.fetchall()
        
        print("allVehicles: ", allVehicles)
        conn.commit()
        # creating a vehicle list and filling it
        vehicle_list = []
        for vehicle in allVehicles:
            object = {
                "vehicle_id" : vehicle[0],
                "vehicle_model" : vehicle[1],
                "vehicle_type" : vehicle[2],
                "seat_formation" : vehicle[3],
                "total_seat_number" : vehicle[4],
                "business_row_number" : vehicle[5]
                
            }
            vehicle_list.append(object)
        
        message = "Vehicles are succesfully fetched."
            
    conn.commit()
    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
            'vehicles' : vehicle_list,
        }
    }

import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    statusCode = 200
    request_type = event["context"]["http-method"]
    body_json = event["body-json"]
    username = body_json['username']
    email = body_json['email']
    user_type = body_json['userType']
    login_info = body_json['loggedin']
    user_id = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        user_id = int(cursor.fetchone()[0])
    
    session = {
        'userid' : user_id,
        'loggedin' : login_info,
        'userType' : user_type
    }

    if not('userid' in session and 'loggedin' in session and session['userType'] == 'admin'):
        statusCode = 400
        message = 'Session was not valid, please log in!'
        return {
            "statusCode" : statusCode,
            "body": {
                "message" : message
            }
        }
    with conn.cursor() as cursor:
        message = None

        if request_type == 'POST':
            if 'terminal_type' in body_json and body_json['terminal_type'] and \
            'terminal_city' in body_json and body_json['terminal_city'] and \
            'terminal_name' in body_json and body_json['terminal_name']:
                
                terminal_type = body_json['terminal_type']
                terminal_city = body_json['terminal_city']
                terminal_name = body_json['terminal_name']

                # check if there is an existing terminal with the same name
                queryFindExistingTerminal = """
                SELECT *
                FROM Terminal
                WHERE name = %s
                """
                cursor.execute(queryFindExistingTerminal, (terminal_name,))
                isExist = cursor.fetchone()

                if isExist:
                    statusCode = 400
                    message = "There is an existing terminal with the same name: " + terminal_name
                else:    
                    # make the insertion
                    # create the vehicle type
                    queryInsertTerminal = """
                    INSERT INTO Terminal (terminal_id, name, city, type)
                    VALUES (NULL, %s, %s, %s)
                    """
                    cursor.execute(queryInsertTerminal, (terminal_name, terminal_city, terminal_type))
                    conn.commit()
                    statusCode = 200
                    message = "New terminal is successfully added!"

            else:
                statusCode = 400
                message = 'Please fill the form!'
    conn.commit()
    return {
        'statusCode': statusCode,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
        }
    }

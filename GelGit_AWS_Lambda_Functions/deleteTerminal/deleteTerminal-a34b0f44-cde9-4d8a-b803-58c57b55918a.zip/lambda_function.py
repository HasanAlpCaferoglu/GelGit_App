import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    statusCode = 200
    request_body = event['body-json']
    userid = None
    loggedin = request_body['loggedin']
    userType = request_body['userType']
    terminalId = event["params"]["path"]["terminal_id"]
    username = request_body['username']
    email = request_body['email']
    
    user_id = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])
    
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }


    if not('userid' in session and 'loggedin' in session and session['userType'] == 'admin'):
        statusCode = 400
        message = 'Session was not valid, please log in!'
        return {
            "statusCode" : 400,
            "message": {
                "message" : message
            }
        }
    with conn.cursor() as cursor:
        message = None

        queryFindVehicleType = """
        SELECT *
        FROM Terminal
        WHERE terminal_id = %s
        """
        cursor.execute(queryFindVehicleType, (terminalId,))
        theTerminal = cursor.fetchone()

        # Find if the terminal used in one of travels
        queryTerminlaUsedInTravel = """
        SELECT *
        FROM Travel
        WHERE departure_terminal_id = %s OR arrival_terminal_id = %s
        """
        cursor.execute(queryTerminlaUsedInTravel, (terminalId, terminalId))
        isUsedInTravels = cursor.fetchall()
        if theTerminal and isUsedInTravels:
            statusCode = 400
            message = "The terminal " + theTerminal[1] + " was used by travels! You cannot delete this terminal!"
        elif theTerminal and not isUsedInTravels:
            queryDeleteTerminal = """
            DELETE FROM Terminal WHERE terminal_id = %s
            """
            cursor.execute(queryDeleteTerminal, (terminalId,))
            cursor.connection.commit()
            print("dgd: ", theTerminal)
            statusCode = 200
            message = "The terminal " + theTerminal[1] + " is deleted."
            
        else:
            statusCode = 404
            message = "There is no such terminal."
    conn.commit()

    return {
        'statusCode': statusCode,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
        }
    }

import json
import sys
import logging
import pymysql
import os
from datetime import datetime

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    print(event)
    request_body = event['body-json']
    userid = None
    loggedin = request_body['loggedin']
    userType = request_body['userType']
    companyId = event["params"]["path"]["company_id"]
    username = request_body['username']
    email = request_body['email']
    
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])
    
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }
  
    if not('userid' in session and 'loggedin' in session and session['userType'] == 'admin'):
        message = 'Session was not valid, please log in!'
        return {
            "statusCode" : 400,
            "message" : message
        }

    with conn.cursor() as cursor:
        message = None

        # Check the company
        queryGetCompany = """
        SELECT company_name
        FROM Company
        WHERE id = %s
        """
        cursor.execute(queryGetCompany, (companyId,))
        companyInfo = cursor.fetchone()

        if companyInfo:
            # Before action, travelers who purchased an upcoming travel registered by the company will be refunded
            queryTravelerAndRefundAmount = """
            SELECT B.traveler_id, P.price, B.PNR, T.travel_id
            FROM Company C
            JOIN Travel T ON T.travel_company_id = C.id
            JOIN Booking B ON B.travel_id = T.travel_id
            JOIN Purchased P ON P.PNR = B.PNR
            WHERE T.depart_time > %s AND C.id = %s
            """
            cursor.execute(queryTravelerAndRefundAmount, (datetime.now(), companyId))
            travelerAndRefundAmount = cursor.fetchall()
            
            queryRefund = """
            UPDATE Traveler
            SET balance = balance + %s
            WHERE id = %s
            """
            
            for data in travelerAndRefundAmount:
                cursor.execute(queryRefund, (data[1], data[0]))
                cursor.connection.commit()

            queryFindUpcomingTravels = """
            SELECT T.travel_id
            FROM Company C
            JOIN Travel T ON T.travel_company_id = C.id
            WHERE T.depart_time > %s AND C.id = %s
            """
            cursor.execute(queryFindUpcomingTravels, (datetime.now(), companyId))
            travelsToBeDeleted = cursor.fetchall()

            # delete travels
            queryDeleteTravel = """
            DELETE FROM Travel WHERE travel_id = %s
            """
            
            for dict in travelsToBeDeleted:
                cursor.execute(queryDeleteTravel, (dict[0], ))
                cursor.connection.commit()

            # deactivate company
            queryDeactivate = """
            UPDATE User SET active = FALSE WHERE id = %s
            """
            cursor.execute(queryDeactivate, (companyId,))
            cursor.connection.commit()
        
            message = 'Company ' + companyInfo[0] + ' is succesfully deactivated. For upcoming travels of the company, paid amounts are refunded to travelers.'
                
        else:
            message = "There is no such company"
    conn.commit()
    
    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
        }
    }

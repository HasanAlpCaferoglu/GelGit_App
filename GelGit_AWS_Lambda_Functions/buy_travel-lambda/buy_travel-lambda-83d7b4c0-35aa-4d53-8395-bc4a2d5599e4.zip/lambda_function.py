import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")

def generatePNR():
    from random import choices
    import string
    return ''.join(choices(string.ascii_uppercase + string.digits, k=10))

def generateSeatNumber(travel_id):
    from random import randint
    return f"Seat-{randint(1, 50)}"  # Assuming each travel has 50 seats

def lambda_handler(event, context):
    user_id = event.get('user_id')
    is_logged_in = event.get('is_logged_in', False)
    selected_coupon_id = None
    travel_id = event.get('travel_id')

    if not travel_id:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Travel ID is required'})
        }

    pnr = generatePNR()
    seat_number = generateSeatNumber(travel_id)
    seat_chosen = False
    reserved_booking = None

    with conn.cursor(pymysql.cursors.DictCursor) as cursor:
        cursor.execute("""
        SELECT c.company_name, dep.name AS departure_terminal, arr.name AS arrival_terminal, t.depart_time, t.price
        FROM Travel t
        JOIN Company c ON t.travel_company_id = c.id
        JOIN Terminal dep ON t.departure_terminal_id = dep.terminal_id
        JOIN Terminal arr ON t.arrival_terminal_id = arr.terminal_id
        WHERE t.travel_id = %s;
        """, (travel_id,))
        travel_details = cursor.fetchone()

        if not travel_details:
            return {
                'statusCode': 404,
                'body': json.dumps({'message': 'Travel details not found'})
            }

        cursor.execute("SELECT balance FROM Traveler WHERE Traveler.id = %s", (user_id,))
        balance = cursor.fetchone()

        if balance is None:
            return {
                'statusCode': 404,
                'body': json.dumps({'message': 'User balance not found'})
            }

        if event.get('apply_coupon'):
            coupon_id = event.get('coupon_id')
            if coupon_id:
                cursor.execute("SELECT sale_rate FROM Sale_Coupon WHERE coupon_id = %s", (coupon_id,))
                coupon = cursor.fetchone()
                if coupon:
                    sale_rate = coupon['sale_rate']
                    discounted_price = travel_details['price'] * (1 - sale_rate)
                    travel_details['discounted_price'] = '{0:.5}'.format(discounted_price)
                selected_coupon_id = coupon_id
            else:
                travel_details['discounted_price'] = travel_details['price']

        if event.get('select_seat'):
            seat_number = event['select_seat']
            seat_chosen = True

        if event.get('action') == 'reserve':
            # Insert booking and reservation data
            reserved_time = datetime.now()
            depart_time = datetime.strptime(travel_details['depart_time'], '%Y-%m-%d %H:%M:%S')
            purchase_deadline = depart_time - timedelta(days=2)
            cursor.execute("INSERT INTO Booking(PNR, travel_id, seat_number, traveler_id) VALUES (%s, %s, %s, %s)", (pnr, travel_id, seat_number, user_id))
            cursor.execute("INSERT INTO Reserved(PNR, reserved_time, purchased_deadline) VALUES (%s, %s, %s)", (pnr, reserved_time, purchase_deadline))
            conn.commit()
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Travel reserved successfully', 'PNR': pnr})
            }

        if event.get('action') == 'purchase':
            # Complete purchase and update balances
            purchase_time = datetime.now()
            cursor.execute("UPDATE Coupon_Traveler SET used_status = True WHERE coupon_id = %s AND user_id = %s", (coupon_id, user_id))
            updated_balance = balance['balance'] - float(travel_details.get('discounted_price', travel_details['price']))
            if updated_balance < 0:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'message': 'Insufficient funds'})
                }
            cursor.execute("INSERT INTO Purchased(PNR, purchased_time, payment_method, price, coupon_id) VALUES (%s, %s, %s, %s, %s)", (pnr, purchase_time, 'credit card', travel_details.get('discounted_price', travel_details['price']), coupon_id))
            cursor.execute("UPDATE Traveler SET Balance = %s WHERE id = %s", (updated_balance, user_id))
            conn.commit()
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Travel purchased successfully'})
            }

    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Operation completed', 'details': travel_details, 'reserved_booking': reserved_booking, 'balance': balance})
    }

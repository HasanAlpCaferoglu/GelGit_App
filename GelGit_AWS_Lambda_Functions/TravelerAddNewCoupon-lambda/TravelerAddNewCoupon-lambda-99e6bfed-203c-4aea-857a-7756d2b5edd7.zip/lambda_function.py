import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance.  
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    # # get info from event
    # request_body = event['body-json']
    # userid = request_body['userid']
    # loggedin = request_body['loggedin']
    # userType = request_body['userType']
    
    print('event: ', event)
    # get info from event
    request_body = event['body-json'] 
    username = request_body['username']
    email = request_body['email']
    userType = request_body['userType']
    loggedin = request_body['loggedin']
    userid = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])
    
    
    entered_coupon_name = request_body["entered_coupon_name"]
    statusCode = 501
    message = "Not implemented"
    
    user_id = userid
    print("user_id: ", user_id)
    print("loggedin: ", loggedin)
    print("userType: ", userType)
    if not(user_id and loggedin and userType == 'traveler'):
        statusCode = 400
        message = 'Session was not valid, please log in!'
        return {
            "statusCode" : statusCode,
            "body": {
                "message" : message
            }
        }
    
    # some example SQL commands
    with conn.cursor() as cursor:
        # Check if the coupon exists in the Sale_Coupon table
        query_check_coupon = """
        SELECT coupon_id, expiration_date, public_status 
        FROM Sale_Coupon 
        WHERE coupon_name = %s
        """
        cursor.execute(query_check_coupon, (entered_coupon_name,))
        coupon = cursor.fetchone()
        
        if coupon:
            coupon_id = coupon[0]
            expiration_date = coupon[1]
            public_status = coupon[2]
            
            # Check if the coupon is already associated with the user
            query_check_exists = """
            SELECT coupon_id 
            FROM Coupon_Traveler 
            WHERE coupon_id = %s 
            AND user_id = %s
            """
            cursor.execute(query_check_exists, (coupon_id, user_id))
            existing_coupon = cursor.fetchone()
            
            if public_status == 'public' and not existing_coupon:
                # Insert the coupon into the Coupon_Traveler table for the user
                query_insert_coupon = "INSERT INTO Coupon_Traveler (coupon_id, user_id) VALUES (%s, %s)"
                cursor.execute(query_insert_coupon, (coupon_id, user_id))
                conn.commit()
                statusCode = 200
                message = "Coupon succesfully added."

            elif public_status == 'private':
                # check if the coupon is associated with any of other user
                query_check_assoc_wit_another_user = """
                SELECT coupon_id 
                FROM Coupon_Traveler 
                WHERE coupon_id = %s 
                AND user_id <> %s
                """
                cursor.execute(query_check_assoc_wit_another_user, (coupon_id, user_id))
                assoc_with_another_user = cursor.fetchone()
                
                if existing_coupon:
                    statusCode = 400
                    message = "Coupon is already associated with your account."
                elif assoc_with_another_user:
                    statusCode = 400
                    message = "Too late :( This coupon is already used by other users! "
                else:
                    # Insert the coupon into the Coupon_Traveler table for the user
                    query_insert_coupon = "INSERT INTO Coupon_Traveler (coupon_id, user_id) VALUES (%s, %s)"
                    cursor.execute(query_insert_coupon, (coupon_id, user_id))
                    conn.commit()
                    statusCode = 200
                    message = "Coupon succesfully added."
            else:
                if existing_coupon:
                    statusCode = 400
                    message = "Coupon is already associated with your account."
        else:
            statusCode = 400
            message = "Invalid coupon name!"

        logger.info(message)
    
    conn.commit()

    return {
        'statusCode': statusCode,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
        }
    }

import json
import sys
import logging
import pymysql
import os
from datetime import datetime

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    request_body = event['body-json']
    loggedin = request_body['loggedin']
    userType = request_body['userType']
    travelId = request_body['travelId']
    username = request_body['username']
    email = request_body['email']

    
    userid = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])
    
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }

    if not('userid' in session and 'loggedin' in session and 'userType' in session and session['userType'] == 'company' or session['userType'] == 'admin'):
        message = 'Session is not valid, please log in!'
        return {
            "statusCode" : 400,
            "message" : message
        }
        
    with conn.cursor() as cursor:

        companyId = userid

        if session['userType'] =='admin':
            companyId = int(event["params"]["path"]["company_id"])
    
        aTravelReservationDetails = None  
        aTravelPurchaseDetails = None 

        #get travel information
        queryGetTravelInfo = """
        SELECT *
        FROM travel_detail_view
        WHERE travel_id = %s
        """
        cursor.execute(queryGetTravelInfo, (travelId, ))
        theTravel = cursor.fetchone()
        print("tttt: ", theTravel)
        if( theTravel[1] != companyId ):
            message= "This travel doesn't belongs to this company. Access Denied!"
        else:
            #get details of purchase, person who purchase this travel etc.
            queryATravelPurchaseDetails= """
            SELECT
            Booking.PNR,
            Booking.seat_number,
            Booking.seat_type,
            Purchased.purchased_time,
            Purchased.payment_method,
            Purchased.price AS amount,
            Sale_Coupon.coupon_name,
            Sale_Coupon.sale_rate,
            Traveler.TCK,
            Traveler.name,
            Traveler.surname
            FROM
            Travel
            JOIN Booking ON Booking.travel_id = Travel.travel_id
            JOIN Traveler ON Traveler.id = Booking.traveler_id
            JOIN Purchased ON Purchased.PNR = Booking.PNR
            LEFT JOIN Sale_Coupon ON Sale_Coupon.coupon_id = Purchased.coupon_id
            WHERE
            Travel.travel_id = %s
            """
            cursor.execute(queryATravelPurchaseDetails, (travelId,))
            aTravelPurchaseDetails = cursor.fetchall()
            
            # Get details of reservations, person who reserved this travel etc.
            # If a travel is past, no need to get the reservations 
            if (theTravel[2] > datetime.now()):
                queryATravelReservationDetails= """
                SELECT
                Booking.PNR,
                Booking.seat_number,
                Booking.seat_type,
                Reserved.reserved_time,
                Reserved.purchased_deadline,
                Traveler.TCK,
                Traveler.name,
                Traveler.surname
                FROM
                Travel
                JOIN Booking ON Booking.travel_id = Travel.travel_id
                JOIN Traveler ON Traveler.id = Booking.traveler_id
                JOIN Reserved ON Reserved.PNR = Booking.PNR
                WHERE
                Travel.travel_id = %s
                """
                cursor.execute(queryATravelReservationDetails, (travelId,))
                aTravelReservationDetails = cursor.fetchall()

        cursor.close()
        current_time = datetime.now()
    conn.commit()
    print("Date: ", current_time)
    print("companyId: ", companyId)
    print("Purchase details: ", aTravelPurchaseDetails)
    print("Reservation Details: ", aTravelReservationDetails)
    print("type: ", type(theTravel[0]))
    theTravel = [str(elem) for elem in theTravel if type(elem) != int]
    purchaseDetails = []
    if aTravelPurchaseDetails !=None:
        for aTravelPurchaseDetail in aTravelPurchaseDetails:
            purchaseDetail = []
            for elem in aTravelPurchaseDetail:
                if type(elem) != int:
                    elem = str(elem)
                purchaseDetail.append(elem)
            purchaseDetails.append(purchaseDetail)
    else:
        purchaseDetails = []
    print("regrg: ", theTravel)
    
    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': "All done!",
            "companyId" : companyId,
            "theTravel" : theTravel,
            "currentTime" : current_time.strftime("%m/%d/%Y, %H:%M:%S"),
            "aTravelPurchaseDetails" : purchaseDetails
        }
    }

import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    reqBody = event['body-json']
    travelId = reqBody['travelId']

    # some example SQL commands
    with conn.cursor() as cursor:

        queryTravel = """
        SELECT c.company_name, dep.name AS departure_terminal, arr.name AS arrival_terminal, t.depart_time, t.arrive_time, t.price
        FROM Travel t
        JOIN Company c ON t.travel_company_id = c.id
        JOIN Terminal dep ON t.departure_terminal_id = dep.terminal_id
        JOIN Terminal arr ON t.arrival_terminal_id = arr.terminal_id
        WHERE t.travel_id = %s;
        """
        cursor.execute(queryTravel, (travelId, ))
        travelDetails = cursor.fetchone()
        if travelDetails:
            print("travelInformation: ", travelDetails)
            travelDetails = list(travelDetails)
            travelDetails[3] = travelDetails[3].isoformat()
            travelDetails[4] = travelDetails[4].isoformat()
            
            travelInformation = {
                "company_name": travelDetails[0],
                "departure_terminal": travelDetails[1],
                "arrival_terminal": travelDetails[2],
                "depart_time": travelDetails[3],
                "arrive_time": travelDetails[4],
                "price": travelDetails[5],
            }
            
            
            return {
                'statusCode': 200,
                'body': {
                    'travelInformation': travelInformation
                }
            }
        else:
            return {
                'statusCode': 404,
                'body': {
                    'message': "Travel information couldn't be found!"
                }
            }
        
    


import json
import sys
import logging
import pymysql
import os
from datetime import datetime

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    print("event: ", event)
    data = event
    
    message = ''
    
    # companyId = str(data["body-json"]["userid"])
    # loggedIn = str(data["body-json"]["loggedin"])
    # userType = str(data["body-json"]["userType"])
    # depTerminalId = str(data["body-json"]["dep_terminal_id"])
    # depTime = str(data["body-json"]["dep_time"])
    # arTerminalId = str(data["body-json"]["ar_terminal_id"])
    # arTime = str(data["body-json"]["ar_time"])
    # vehicTypeId = str(data["body-json"]["vehic_type_id"])
    # vehicType = str(data["body-json"]["vehic_type"])
    # price = str(data["body-json"]["price"])
    # businessPrice = str(data["body-json"]["business_price"])
    
    
    body_json = data["body-json"]
    
    loggedIn = body_json["loggedin"]
    userType = body_json["userType"]
    depTerminalId = body_json["dep_terminal_id"]
    depTime = body_json["dep_time"]
    arTerminalId = body_json["ar_terminal_id"]
    arTime = body_json["ar_time"]
    vehicTypeId = body_json["vehic_type_id"]
    vehicType = body_json["vehic_type"]
    price = body_json["price"]
    businessPrice = body_json["business_price"]
    email = body_json['email']
    
    companyId = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        companyId = int(cursor.fetchone()[0])
    
    print("companyId: ", companyId)
    print("loggedIn: ", loggedIn)
    print("userType: ", userType)
    if companyId and loggedIn and userType and userType == 'company':
        with conn.cursor() as cursor:
            
            if not depTerminalId or not arTerminalId or not depTime or not arTime or not vehicTypeId or not price:
                message = 'Please fill the form!'
            elif( depTime < str(datetime.now()) ):
                message = "You can not create a travel with a date of departure in the past!"
            elif( arTime < depTime ):
                message = "You can not create a travel with an arrival time earlier then departure time!"
            else:
                travel_add_query = """
                INSERT INTO Travel (travel_id, travel_company_id, departure_terminal_id, arrival_terminal_id, depart_time, arrive_time, price, business_price, vehicle_type_id)
                VALUES (NULL, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(travel_add_query, (companyId, depTerminalId, arTerminalId, depTime, arTime, price, businessPrice, vehicTypeId))
                message = 'Travel is added!'
            
        conn.commit()
        cursor.close()

        return {
            'statusCode': 200,  # Customizing the status code
            'body':{
                'message': message  # Including custom message in the response body
            }
        }
        
    else:
        
        return {
            'statusCode': 400,  # Customizing the status code
            'body':{
                'message': message,  # Including custom message in the response body
                #'session_info': session_info
            }
        }

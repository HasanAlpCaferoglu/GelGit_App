import json
import sys
import logging
import pymysql
import os
"""DONE (session is hardcoded) (form datas are assumed as None values)"""
"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    
    # get info from event
    data = event
    request_type = event["context"]["http-method"]
    
    print("event: ", event)
    print("context: ", context)
    body_json = event["body-json"]
    username = body_json['username']
    email = body_json['email']
    userType = body_json['userType']
    loggedin = body_json['loggedin']
    userid = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])
    
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }

    if not('userid' in session and 'loggedin' in session):
        message = "Session info is not found."
        return {
            'statusCode': 400,  # Customizing the status code
            'body': {
            'message': message,  # Including custom message in the response body
            #'session_info': session_info
            }
        }
        
    user_id = session['userid']
    print("user_id", user_id)
    if request_type == 'POST':
        # Get user information
        with conn.cursor() as cursor:
            query = """
            SELECT id, email, phone, TCK, name, surname, age, balance
            FROM User U NATURAL JOIN Traveler T
            WHERE U.id = %s AND U.active = TRUE
            """
            cursor.execute(query, (user_id,))
            userCurrentInfo = cursor.fetchone()
            
            if 'email' in event['body-json']:
                newEmail = event['body-json']['email']
            else:
                newEmail = None
            if 'phone' in event['body-json']:
                newPhone = event['body-json']['phone'] 
            else:
                newPhone = None
            if 'name' in event['body-json']:
                newName = event['body-json']['name']  
            else:
                newName = None
            if 'surname' in event['body-json']:
                newSurname = event['body-json']['surname']
            else:
                newSurname = None
            if 'age' in event['body-json']:
                newAge = event['body-json']['age']
            else:
                newAge = None

            if newEmail and newPhone:
                if (userCurrentInfo[1] != newEmail or userCurrentInfo[2] != newPhone):
                    updateQuery = "UPDATE User SET email = %s, phone = %s WHERE id = %s"
                    cursor.execute(updateQuery, (newEmail, newPhone, user_id,))
            if newName and newSurname and newAge:
                if (userCurrentInfo[4] != newName or userCurrentInfo[5] != newSurname or userCurrentInfo[6] != newAge):
                    updateQuery = "UPDATE Traveler SET name = %s, surname = %s, age = %s WHERE id = %s"
                    cursor.execute(updateQuery, (newName, newSurname, newAge, user_id,))
            conn.commit()
        conn.commit()
        
    message = "Süper süper!"
    logger.info(message)
    
    

    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
            "user_id": user_id,
            'some_other_data': 'value',  # Including additional data
        }
    }

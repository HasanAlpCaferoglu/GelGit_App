import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    """
    This function inserts a new tuple to Traveler and User Tables
    """
    # message = event['Records'][0]['body']
    # data = json.loads(message)
    print('event: ', event)
    data = event
    companyName = data['companyName']
    companyEmail = data['companyEmail']
    password = data['password']
    passwordRepeat = data['passwordRepeat']
    companyPhone = data['companyPhone']
    website = data['website']
    foundationDate = data['foundationDate']
    aboutCompany = data['aboutCompany']

    with conn.cursor() as cursor:
        
        cursor.execute('SELECT * FROM User WHERE email = %s ', (companyEmail, ))
        accountExistWithSameEmail = cursor.fetchone()
        
        cursor.execute('SELECT * FROM User WHERE phone = %s ', (companyPhone, ))
        accountExistWithSamePhone = cursor.fetchone()

        cursor.execute('SELECT * FROM Company WHERE company_name = %s ', (companyName, ))
        accountExistWithSameName = cursor.fetchone()

        cursor.execute('SELECT * FROM Company WHERE website = %s ', (website, ))
        accountExistWithSameWebsite = cursor.fetchone()

        if not companyName or not companyEmail or not password or not passwordRepeat or not companyPhone or not website:
            message = 'Please fill out the required fields!'
        elif accountExistWithSameEmail:
            message = 'There is already a company with that email!'
        elif accountExistWithSameName:
            message = 'There is already a company with this Name!'
        elif accountExistWithSamePhone:
            message = 'There is already a company with this phone number!'
        elif accountExistWithSameWebsite:
            message = 'There is already a company with this website!'
        elif password != passwordRepeat:
            message = 'Password mismatch. Please enter same password!'   
        else:
            cursor.execute('INSERT INTO User (id, email, password, phone, active) VALUES (NULL, % s, % s, % s, TRUE)', (companyEmail, password, companyPhone, ))
            conn.commit()
            # find newly added traveler
            cursor.execute('SELECT * FROM User WHERE email = %s ', (companyEmail, ))
            newUser = cursor.fetchone()
            # get the user id and insert this user into Traveler
            newCompanyId = newUser[0] # index 0 corresponds to the id
            cursor.execute('INSERT INTO Company (id,  company_name, website, foundation_date, about, validator_id, validation_date) VALUES (%s, % s, % s, % s, %s, NULL, NULL)', (newCompanyId, companyName, website, foundationDate, aboutCompany, ))
            conn.commit()
            message = 'Comany successfully created! Please wait to be validated.'
            
        logger.info(message)
            
    conn.commit()
    
    response_body = {
        'message': message,
        'redirect_url': '/travelerRegister'
    }
   
    return {
        'statusCode': 200,
        'body': response_body
    }

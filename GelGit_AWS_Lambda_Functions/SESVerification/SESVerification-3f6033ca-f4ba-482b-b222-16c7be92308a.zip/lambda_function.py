import json
import boto3

def lambda_handler(event, context):
    # Cognito tarafından tetiklenen olayları kontrol et
    if event['triggerSource'] == 'PostConfirmation':
        # Doğrulanan kullanıcının e-posta adresini al
        email = event['request']['userAttributes']['email']
        
        # SES ile doğrulama e-postasını gönder
        ses_client = boto3.client('ses')
        sender_email = 'gelgitapp@gmail.com'  # Gönderen e-posta adresi
        subject = 'Account Verification'  # E-posta konusu
        body = 'Please verify your account.'  # E-posta gövdesi
        
        response = ses_client.send_email(
            Source=sender_email,
            Destination={
                'ToAddresses': [email]
            },
            Message={
                'Subject': {'Data': subject},
                'Body': {'Text': {'Data': body}}
            }
        )
        
        print("Verification email sent to:", email)
        
        return {
            'statusCode': 200,
            'body': json.dumps('Verification email sent successfully!')
        }
    else:
        return {
            'statusCode': 400,
            'body': json.dumps('Unsupported triggerSource!')
        }
import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    print('hello alp')
    print('event: ', event)
    print('context', context)
    pathParams = event.get('pathParameters')
    print('pathParams: ', pathParams)
    
    #get cities from terminal table to show in drop down menu
    with conn.cursor() as cursor:
        #get cities from terminal table to show in drop down menu
        cursor.execute("SELECT DISTINCT city FROM Terminal ORDER BY city ASC")
        all_cities = cursor.fetchall()
        print('all_cities: ', all_cities)
        cities = [row[0] for row in all_cities]
        print('cities:', cities)

    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'cities': cities, 
        }
    }

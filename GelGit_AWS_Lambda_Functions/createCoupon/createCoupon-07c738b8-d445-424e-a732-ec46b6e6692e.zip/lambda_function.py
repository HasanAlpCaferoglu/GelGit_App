import json
import sys
import logging
import pymysql
import os
from datetime import datetime

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    request_type = event["context"]["http-method"]
    body_json = event["body-json"]

    username = body_json['username']
    email = body_json['email']
    user_type = body_json['userType']
    login_info = body_json['loggedin']
    user_id = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        user_id = int(cursor.fetchone()[0])
    
    session = {
        'userid' : user_id,
        'loggedin' : login_info,
        'userType' : user_type
    }

   
    if not('userid' in session and 'loggedin' in session and session['userType'] == 'admin'):
        message = 'You are not authorized!'
        return {
            'statusCode' : 400,
            'body': {
                'message' : message
            }
        }
        
    message = None
    with conn.cursor() as cursor:

        if request_type == 'POST':
            if 'coupon_name' in body_json and body_json['coupon_name'] and \
            'sale_rate' in body_json and body_json['sale_rate'] and \
            'expiration_date' in body_json and body_json['expiration_date'] and \
            'public_status' in body_json and body_json['public_status']:
                
                coupon_name = body_json['coupon_name']
                sale_rate = body_json['sale_rate']
                expiration_date = body_json['expiration_date'][:10] # getting only the date part
                public_status = body_json['public_status']
                current_date = datetime.now().strftime("%Y-%m-%d")

                # check if sale rate is between 0 to 1
                if float(sale_rate) < 0.0 or float(sale_rate) > 1.0:
                    message = 'Sale rate must be between 0 and 1'
                    return {
                        'statusCode' : 400,
                        'body': {
                            'message' : message
                        }
                    }

                #check if there is a non-expired coupon with the given name
                queryFindCoupon = """
                SELECT *
                FROM Sale_Coupon
                WHERE coupon_name = %s AND expiration_date > %s AND public_status = %s
                """
                cursor.execute(queryFindCoupon, (coupon_name, current_date, public_status))
                existingCoupon = cursor.fetchone()
                if existingCoupon:
                    message = 'There is an available coupon with ' + coupon_name + ' name! '
                    message = message + 'To be able to create a coupon with the same name, the expiration date of existing coupon must be passed.'
                else:
                    # create new coupon and insert in to Sale_Coupon table
                    queryInsertCoupon = """
                    INSERT INTO Sale_Coupon (coupon_id, coupon_name, sale_rate, expiration_date, generation_date, public_status)
                    VALUES (NULL, %s, %s, %s, %s, %s)
                    """
                
                    cursor.execute(queryInsertCoupon, (coupon_name, sale_rate, expiration_date, current_date, public_status))
                    cursor.connection.commit()
                    message = 'A coupon with ' + coupon_name + ' name, ' + str(sale_rate) + ' sale rate, ' + expiration_date + ' expiration date and with ' + public_status + ' availability is created.'

            else:
                message = 'Please fill the form!'
                return {
                    'statusCode': 400,
                    'body': {
                        "message": message
                    }
                }
    conn.commit()
    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
        }
    }

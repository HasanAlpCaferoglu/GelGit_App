import json
import sys
import logging
import pymysql
import os
from datetime import datetime

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=50)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    request_body = event['body-json']
    userid = request_body['userid']
    loggedin = request_body['loggedin']
    userType = request_body['userType']
    travelId = request_body['travelId']
    if request_body['getInfo'] == 'True':
        getInfo = True
    else:
        getInfo = False
        
    print("EVENT: ", event)
    session = {
        'userid' : userid,
        'loggedin' : loggedin,
        'userType' : userType
    }

    if not('userid' in session and 'loggedin' in session and 'userType' in session and session['userType'] == 'company'):
        message = 'Session is not valid, please log in!'
        return {
            "statusCode" : 400,
            "message" : message
        }
        
    companyId = session['userid']
    isEditable = True
    message = ''
    with conn.cursor() as cursor:
            
        queryGetTravelInfo = """
        SELECT *
        FROM travel_detail_view
        WHERE travel_id = %s
        """
        cursor.execute(queryGetTravelInfo, (travelId, ))
        theTravel = cursor.fetchone()
        print("thtehehe: ", theTravel)
        # Check if the travel is of the logged in company
        if( theTravel[1] != companyId):
            message = "This travel doesn't belong to your company. You cannot edit!"
            isEditable = False
            return {
                'statusCode' : 400,
                'message' : message,
                'theTravel' : theTravel
            }
        elif( theTravel[2] < datetime.now()): # check if the travel is past travel
            message = "This travel has been made. You cannot edit past travels!"
            isEditable = False
            return {
                'statusCode' : 400,
                'message' : message,
                'theTravel' : theTravel
            }
        else:
            isEditable = True
            print("Travelslslsl: ", theTravel)
            travelVehicleType = theTravel[11] # get the vehicle type such as plane, bus or train
            # get available terminals depending on the vehicle type
            queryAllAvailableTerminals = """
            SELECT *
            FROM Terminal
            WHERE active_status = 'active'AND type = %s
            ORDER BY city, name
            """
            cursor.execute(queryAllAvailableTerminals, (travelVehicleType,))
            allAvailableTerminals = cursor.fetchall()

            #get all vehicle models and models depending on type
            queryAllAvailableVehicleTypes = """
            SELECT *
            FROM Vehicle_Type
            WHERE type = %s
            ORDER BY model
            """
            cursor.execute(queryAllAvailableVehicleTypes, (travelVehicleType, ))
            allAvailableVehicleTypes = cursor.fetchall()
        
            # Get the information from the form 
            # Update the travel information
            if not getInfo:
                # get values from the request form
                dep_terminal_id = request_body['dep_terminal_id']
                ar_terminal_id = request_body['ar_terminal_id']
                dep_time = request_body['dep_time']
                ar_time = request_body['ar_time']
                vehic_type_id = request_body['vehic_type_id']
                price = request_body['price']
                business_price = request_body['business_price']
                
                # dep_time_converted = datetime.strptime(dep_time, '%Y-%m-%d %H:%M:%S')
                if not dep_terminal_id or not ar_terminal_id or not dep_time or not ar_time or not vehic_type_id or not price:
                    message = 'Please fill the form!'
                elif( dep_time < str(datetime.now()) ):
                    message = "You cannot edit travel so that departure time is before now!"
                elif( ar_time < dep_time ):
                    message = "You cannot edit travel so that arrival time is before the departure time!"
                else:
                    queryUpdateTravel = """
                    UPDATE Travel
                    SET
                    departure_terminal_id = %s,
                    arrival_terminal_id = %s,
                    depart_time = %s,
                    arrive_time = %s,
                    price = %s,
                    business_price = %s, 
                    vehicle_type_id = %s
                    WHERE travel_id = %s AND travel_company_id = %s
                    """
                    cursor.execute(queryUpdateTravel, ( dep_terminal_id, ar_terminal_id, dep_time, ar_time, price, business_price, vehic_type_id, travelId, companyId,))
                    # Commit the changes to the database
                    conn.commit()
                    message = 'Travel is successfully updated!' 
                    # Get updated travel
                    cursor.execute(queryGetTravelInfo, (travelId, ))
                    theTravel = cursor.fetchone()
    conn.commit()
    theTravel = [str(elem) for elem in theTravel if type(elem) != int]
    print("isEditable: ", isEditable)
    print("allAvailableTerminals: ", allAvailableTerminals)
    print("allAvailableVehicleTypes: ", allAvailableVehicleTypes)
    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,
            'isEditable' : isEditable,
            'theTravel' : theTravel,
            'allAvailableTerminals' : allAvailableTerminals,
            'allAvailableVehicleTypes' : allAvailableVehicleTypes
        }
    }

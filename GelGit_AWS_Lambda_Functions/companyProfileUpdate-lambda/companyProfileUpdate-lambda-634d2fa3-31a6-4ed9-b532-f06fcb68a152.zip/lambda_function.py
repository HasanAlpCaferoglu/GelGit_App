import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    print("event: ", event)
    print("context: ", context)
    body_json = event["body-json"]
    
    user_id = body_json["userid"]
    login_info = body_json["loggedin"]
    user_type = body_json["userType"]
    
    new_company_name = body_json["company_name"]
    new_company_phone = body_json["company_phone"]
    new_company_email = body_json["company_email"]
    new_company_website = body_json["company_website"]
    new_company_foundation_date = body_json["company_foundation_date"]
    new_company_about = body_json["company_about"]
    
    message = ""
    
    if not login_info:
        return {
            "statusCode": 401,
            "body": {
                "message": "Please log in!"
            }
        }
    if user_type == 'traveler':
        return {
            "statusCode": 401,
            "body": {
                "message": "As a traveler, you are unauthorized to take this action!"
            }
        }
    

    # some example SQL commands
    with conn.cursor() as cursor:
        
        # Get company information
        queryGetCompany = """
        SELECT id, email, phone, company_name, website, foundation_date, about
        FROM User U NATURAL JOIN Company C
        WHERE C.id = %s AND U.active = TRUE
        """
        cursor.execute(queryGetCompany, (user_id,))
        companyCurrentInfo = cursor.fetchone()
        
        current_email = companyCurrentInfo[1]
        current_phone = companyCurrentInfo[2]
        current_name = companyCurrentInfo[3]
        current_website = companyCurrentInfo[4]
        current_foundation_date = companyCurrentInfo[5]
        current_about = companyCurrentInfo[6]
        
        if current_email != new_company_email or current_phone != new_company_phone:
            updateQuery = "UPDATE User SET email = %s, phone = %s WHERE id = %s"
            cursor.execute(updateQuery, (new_company_email, new_company_phone, user_id,))
        
        if current_name != new_company_name or current_website != new_company_website or current_foundation_date != new_company_foundation_date or current_about != new_company_about:
            updateQuery = "UPDATE Company SET company_name = %s, website = %s, foundation_date = %s, about = %s WHERE id = %s"
            cursor.execute(updateQuery, (new_company_name, new_company_website, new_company_foundation_date, new_company_about, user_id,))
            
        # commit the changes to the database
        conn.commit()
        message = 'Company information updated successfully!'
        logger.info(message)
        
        query = """
        SELECT id, email, phone, company_name, website, foundation_date, about
        FROM User U NATURAL JOIN Company C
        WHERE U.id = %s AND U.active = TRUE
        """
        cursor.execute(query, (user_id,))
        companyInfo = cursor.fetchone()
        companyProfile = {
            "user_id": companyInfo[0],
            "company_email": companyInfo[1],
            "company_phone": companyInfo[2],
            "company_name": companyInfo[3],
            "company_website": companyInfo[4],
            "company_foundation_date": companyInfo[5].isoformat(),
            "company_about": companyInfo[6]
        }
    
    conn.commit()

    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
            'companyProfile': companyProfile,  # Including email for reference
        }
    }

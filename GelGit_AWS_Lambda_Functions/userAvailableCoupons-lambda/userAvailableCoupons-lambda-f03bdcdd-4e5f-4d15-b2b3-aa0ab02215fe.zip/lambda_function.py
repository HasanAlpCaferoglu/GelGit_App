import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
 
    # get info from event
    # request_body = event['body-json']
    # userid = request_body['userid']
    # loggedin = request_body['loggedin']
    # userType = request_body['userType']
    print(event)
    request_body = event['body-json'] 
    username = request_body['username']
    email = request_body['email']
    userType = request_body['userType']
    loggedin = request_body['loggedin']
    userid = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        userid = int(cursor.fetchone()[0])

    message = ""
    user_past_coupons = []
    user_available_coupons = []
    
    # some example SQL commands
    with conn.cursor() as cursor:
        
        if userid and loggedin:
            # Get available coupons
            query_get_coupons = """
            SELECT SC.coupon_name, SC.sale_rate, SC.coupon_id
            FROM Sale_Coupon SC
            INNER JOIN Coupon_Traveler CT ON SC.coupon_id = CT.coupon_id
            WHERE CT.user_id = %s AND CT.used_status = FALSE
            """
            cursor.execute(query_get_coupons, (userid,))
            coupons = cursor.fetchall()
            
            user_available_coupons = [{"coupon_name": c[0], "sale_rate": c[1], "coupon_id": c[2]} for c in coupons]
            
            # Get past coupons
            query_get_past_coupons = """
            SELECT SC.coupon_name, SC.sale_rate, SC.coupon_id
            FROM Sale_Coupon SC
            INNER JOIN Coupon_Traveler CT ON SC.coupon_id = CT.coupon_id
            WHERE CT.user_id = %s AND CT.used_status = TRUE
            """
            cursor.execute(query_get_past_coupons, (userid,))
            past_coupons = cursor.fetchall()
            
            user_past_coupons = [{"coupon_name": c[0], "sale_rate": c[1], "coupon_id": c[2]} for c in past_coupons]
            
            
        else:
            message = "Please Log in!"
            return{
                "statusCode": 400,
                "body": {
                    "message": message
                }
            }

        logger.info(message)
    
    conn.commit()
    print("user_available_coupons: ", user_available_coupons)
    print("user_past_coupons: ", user_past_coupons)

    return {
        'statusCode': 200,  # Customizing the status code
        'body': {
            'message': message,  # Including custom message in the response body
            'user_available_coupons': user_available_coupons,  
            'user_past_coupons': user_past_coupons
        }
    }

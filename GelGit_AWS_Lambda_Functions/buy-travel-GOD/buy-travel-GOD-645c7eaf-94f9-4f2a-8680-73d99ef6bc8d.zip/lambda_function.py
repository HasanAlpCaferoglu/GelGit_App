import json
import sys
import logging
import pymysql
import os
import random
import string
from datetime import datetime
import boto3
from botocore.exceptions import ClientError
import urllib3

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

def send_email():
    SENDER = "gelgitapp@gmail.com" # must be verified in AWS SES Email
    RECIPIENT = "canbagirgan@gmail.com" # must be verified in AWS SES Email

    # If necessary, replace us-west-2 with the AWS Region you're using for Amazon SES.
    AWS_REGION = "us-east-1"

    # The subject line for the email.
    SUBJECT = "This is test email for testing purpose..!!"

    # The email body for recipients with non-HTML email clients.
    BODY_TEXT = ("Hey Hi...\r\n"
                "This email was sent with Amazon SES using the "
                "AWS SDK for Python (Boto)."
                )
                
    # The HTML body of the email.
    BODY_HTML = """<html>
    <head></head>
    <body>
    <h1>Hey Hi...</h1>
    <p>This email was sent with
        <a href='https://aws.amazon.com/ses/'>Amazon SES CQPOCS</a> using the
        <a href='https://aws.amazon.com/sdk-for-python/'>
        AWS SDK for Python (Boto)</a>.</p>
    </body>
    </html>
                """            

    # The character encoding for the email.
    CHARSET = "UTF-8"

    # Create a new SES resource and specify a region.
    client = boto3.client('ses',region_name=AWS_REGION)

    # Try to send the email.
    try:
        #Provide the contents of the email.
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    RECIPIENT,
                ],
            },
            Message={
                'Body': {
                    'Html': {
        
                        'Data': BODY_HTML
                    },
                    'Text': {
        
                        'Data': BODY_TEXT
                    },
                },
                'Subject': {

                    'Data': SUBJECT
                },
            },
            Source=SENDER
        )
    # Display an error if something goes wrong.	
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")
PNR_LENGTH = 8
def generatePNR():
    with conn.cursor() as cursor:

        while(True):
            length = PNR_LENGTH
            chars = string.ascii_uppercase + string.digits
            pnr = ''.join(random.choice(chars) for _ in range(length))
    
            # Check if pnr unique
            query_pnr_check = """
            SELECT COUNT(*) AS count
            FROM Booking 
            WHERE PNR = %s
            """
            cursor.execute(query_pnr_check, (pnr,))
            result = cursor.fetchone()
            print("kadriii: ", result)
            if(result[0] == 0):
                break
    conn.commit()
    
    return pnr

def lambda_handler(event, context):
    print(event)
    request_type = event["context"]["http-method"]
    # body_json = event["body-json"]
    # user_id = body_json["userid"]
    # login_info = body_json["loggedin"]
    # user_type = body_json["userType"]
    
    # get info from query path
    travel_id = event["params"]["path"]["travel_id"]
    seat_number = int(event["params"]["path"]["seat_number"])
    # get info from event
    body_json = event['body-json'] 
    username = body_json['username']
    email = body_json['email']
    user_type = body_json['userType']
    login_info = body_json['loggedin']
    user_id = None
    with conn.cursor() as cursor:
        getUserIdQuery = "SELECT id FROM User WHERE email = %s"
        cursor.execute(getUserIdQuery, (email,))
        user_id = int(cursor.fetchone()[0])
    
    seat_number = int(event["params"]["path"]["seat_number"])
    print(user_id)
    
    pnr = generatePNR()
    
    session = {
        'userid' : user_id,
        'loggedin' : login_info,
        'userType' : user_type
    }
    with conn.cursor() as cursor:

        query_seats = """
        SELECT num_of_seats, vehicle_type_id 
        FROM Travel 
        JOIN Vehicle_Type ON Travel.vehicle_type_id = Vehicle_Type.id 
        WHERE travel_id = %s
        """
        cursor.execute(query_seats, (travel_id,))
        result = cursor.fetchone()
        print("Result: ", result[0], result[1])
        total_seats = result[0]
    
        # Count the number of bookings made for the given travel
        query_num_bookings = """
        SELECT COUNT(*) 
        FROM Booking 
        WHERE travel_id = %s
        """
        cursor.execute(query_num_bookings, (travel_id,))
        booked_seats = cursor.fetchall()[0]
    
        # Generate random valid seat number
        while(True):

            # Check if the randomly generated seat number is already booked
            query_check_seat = """
            SELECT COUNT(*) AS occupied
            FROM Booking 
            WHERE travel_id = %s AND seat_number = %s
            """
            cursor.execute(query_check_seat, (travel_id, seat_number))
            result = cursor.fetchone()
            seat = result[0]
    
            if(seat == 0):
                break
    conn.commit()
    
    
    seat_chosen = False
    reserved_booking = None
    user_id = session['userid']
    
    
    
    with conn.cursor() as cursor:
        # Get travel details
        query_travel = """
        SELECT c.company_name, dep.name AS departure_terminal, arr.name AS arrival_terminal, t.depart_time, t.price
        FROM Travel t
        JOIN Company c ON t.travel_company_id = c.id
        JOIN Terminal dep ON t.departure_terminal_id = dep.terminal_id
        JOIN Terminal arr ON t.arrival_terminal_id = arr.terminal_id
        WHERE t.travel_id = %s;
        """
        cursor.execute(query_travel, (travel_id,))
        travel_details = cursor.fetchone()
        print("TRAVEL DETAILS: ", travel_details)
        # Get balance
        query_balance = """
        SELECT balance
        FROM Traveler
        WHERE Traveler.id = %s
        """
        cursor.execute(query_balance, (user_id,))
        balance = cursor.fetchone()
        print("BALANCE: ", balance)
    
        # Get coupons
        query_coupons = """
        SELECT SC.coupon_name, SC.sale_rate, SC.coupon_id
        FROM Sale_Coupon SC
        INNER JOIN Coupon_Traveler CT ON SC.coupon_id = CT.coupon_id
        WHERE CT.user_id = %s AND CT.used_status = FALSE
        """
        cursor.execute(query_coupons, (user_id,))
        coupons = cursor.fetchall()
        print("COUPONS: ", coupons)
        
        # Get list of all journeys
        #query_journey = """
        #SELECT *
        #FROM Journey J
        #WHERE J.traveler_id = %s
        #"""
        #cursor.execute(query_journey, (user_id,))
        #journeys = cursor.fetchall()
        #print("JOURNEYS: ", journeys)

        # Check if travel is associated with a journey
        #query_check_journey = """
        #SELECT COUNT(*) AS cnt
        #FROM Travels_In_Journey 
        #WHERE travel_id = %s;
        #"""
        #cursor.execute(query_check_journey, (travel_id,))
        #print("NEDİR BU1?", cursor.fetchone())
        
        #journey_count = cursor.fetchone()
        #print(journey_count)
    
        #query_journey_name = """
        #SELECT journey_name
        #FROM Travels_In_Journey 
        #WHERE travel_id = %s;
        #"""
        #cursor.execute(query_journey_name, (travel_id,))
        #journey = cursor.fetchone()
        #print("JOURNEY?: ", journey)
        #journey_name = None
        #if journey:
        #    journey_name = journey[0]
    
        #if request_type == 'POST' and "addTravelToJourney" in event["params"]["querystring"]:
        #    if 'selectedJourney' in event["params"]["querystring"]:
        #        selected_journey = event["params"]["querystring"]["selectedJourney"]
            
        #        query_addTravelToJourney = """
        #        INSERT INTO Travels_In_Journey VALUES
        #        (%s, %s, %s)
        #        """
        #        cursor.execute(query_addTravelToJourney, (selected_journey, user_id, travel_id,))
        #        conn.commit()
            # return redirect(url_for('journeys')) ROUTING????
        #    """
        #    return {
        #        'statusCode': 200,  # Customizing the status code
        #        'body': {
        #            'message': "SUCCESS",  # Including custom message in the response body
        #            'some_other_data': 'value',  # Including additional data
        #        }
        #    }
        #    """
        
    conn.commit()
    
    #with conn.cursor() as cursor:

        # apply coupon
        #if request_type == 'POST':
        #    if 'coupon_id' in event["params"]["querystring"]:
        #        coupon_id = int(event["params"]["querystring"]["coupon_id"])
        #    else:
        #        coupon_id = None
        #    if coupon_id:
        #        selected_coupon_id = coupon_id
                # Fetch the coupon details based on the coupon ID
        #        query_coupon = """
        #        SELECT sale_rate
        #        FROM Sale_Coupon
        #        WHERE coupon_id = %s
        #        """
        #        cursor.execute(query_coupon, (coupon_id,))
        #        coupon = cursor.fetchone()
        #        sale_rate = coupon['sale_rate']
                
                # Calculate the discounted price
        #        discounted_price = travel_details['price'] * (1 - sale_rate)
                
                # Update the travel_details dictionary with the discounted price
        #        travel_details['discounted_price'] = '{0:.5}'.format(discounted_price)
        #    else:
        #        selected_coupon_id = None
        #        travel_details['discounted_price'] = travel_details['price']
    #conn.commit()

    #with conn.cursor() as cursor:

    #    if request_type == "POST" and 'seat_number' in event["params"]["querystring"]:
    #        if event["params"]["querystring"]["seat_number"]:
    #            seat_number = event["params"]["querystring"]["seat_number"]
    #            seat_chosen = True
    
    #    if request_type == "POST" and 'reserve_PNR' in event["params"]["querystring"]:
    #        pnr = event["params"]["querystring"]["reserve_PNR"]
    
    #        query_reserved_booking = """
    #        SELECT *
    #        FROM Booking
    #        WHERE PNR = %s
    #        """
    #        cursor.execute(query_reserved_booking, (pnr, ))
    #        reserved_booking = cursor.fetchone()
    #        print("RESERVE BOOKING: ", reserved_booking)
            
    #        seat_number = reserved_booking['seat_number']
    #        seat_chosen = True
    #conn.commit()
    
    #with conn.cursor() as cursor:

    #    # reserve
    #    if request_type == 'POST':
    #        ## do not deduct from balance
    #        # Generate the current timestamp
    #        reserved_time = datetime.now()
    
    #        # Calculate the purchase deadline (2 days before departure time)
    #        depart_time = travel_details['depart_time']
    #        purchase_deadline = depart_time - timedelta(days=2)
            
    #        query_insert_booking = """
    #        INSERT INTO Booking(PNR, travel_id, seat_number, traveler_ied)
    #        VALUES (%s, %s, %s, %s)
    #        """
    #        cursor.execute(query_insert_booking, (pnr, travel_id, seat_number, user_id))
    
    #        # Insert data into Reserved table
    #        query_insert_reserved = """
    #        INSERT INTO Reserved(PNR, reserved_time, purchased_deadline)
    #        VALUES (%s, %s, %s)
    #        """
    #        cursor.execute(query_insert_reserved, (pnr, reserved_time, purchase_deadline))
    #       conn.commit()
    
    #        #return redirect(url_for('myTravels')) ROUTING??
    #        """
    #        return {
    #            'statusCode': 200,  # Customizing the status code
    #            'body': {
    #                'message': "SUCCESS",  # Including custom message in the response body
    #                'some_other_data': 'value',  # Including additional data
    #            }
    #        }
    #        """
    #conn.commit()
    
    with conn.cursor() as cursor:

        # purchase
        if request_type == 'POST':
            
            # Generate the current timestamp
            purchase_time = datetime.now()
    
            # Check if a coupon is used
            coupon_id = body_json["coupon_id"]
    
            # Calculate the price to be deducted from the balance
            if coupon_id:
                # Fetch the coupon details based on the coupon ID
                query_coupon = """
                SELECT sale_rate
                FROM Sale_Coupon
                WHERE coupon_id = %s
                """
                cursor.execute(query_coupon, (coupon_id,))
                coupon = cursor.fetchone()
                
                sale_rate = coupon[0]
    
                # Update the coupon to be used
                query_update_coupon = """
                UPDATE Coupon_Traveler
                SET used_status = %s
                WHERE coupon_id = %s 
                AND user_id = %s
                """
                cursor.execute(query_update_coupon, (True, coupon_id, user_id))
                conn.commit()
                print("teeere:", travel_details)
                # Calculate the discounted price
                discounted_price = travel_details[4] * (1 - sale_rate)
            else:
                # No coupon applied, use the original price
                discounted_price = travel_details[4]
    
            # Calculate the updated balance
            updated_balance = balance[0] - discounted_price
    
            # Check if user has sufficient funds
            if updated_balance < 0:
                return {
                'statusCode': 400,  # Customizing the status code
                'body': {
                    "message" : "Insuffiecient funds!",
                    "travel_id" : travel_id
                }
            }
    
            
            query_insert_booking = """
            INSERT INTO Booking(PNR, travel_id, seat_number, traveler_id)
            VALUES (%s, %s, %s, %s)
            """
            cursor.execute(query_insert_booking, (pnr, travel_id, seat_number, user_id))
    
            query_insert_purchased = """
            INSERT INTO Purchased(PNR, purchased_time, payment_method, price, coupon_id)
            VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(query_insert_purchased, (pnr, purchase_time, 'credit card', discounted_price, coupon_id))

            query_update_balance = """
            UPDATE Traveler
            SET Balance = %s
            WHERE id = %s
            """
            cursor.execute(query_update_balance, (updated_balance, user_id))
            user_email_query = """
            SELECT email 
            FROM User
            WHERE id = %s
            """
            cursor.execute(user_email_query, (user_id,))
            user_email = cursor.fetchone()[0]
            
            conn.commit()
    conn.commit()
    
            
            #return redirect(url_for('myTravels'))
            
    
    #return render_template('purchasePage.html', travel_id=travel_id, travel_details=travel_details, reserved_booking=reserved_booking, balance=balance, coupons=coupons, pnr=pnr, seat_number=seat_number, seat_chosen=seat_chosen, is_logged_in=is_logged_in, user_id=user_id, selected_coupon_id=selected_coupon_id, journeys = journeys, journey_count=journey_count, journey_name=journey_name)
    
    print("travel_id: ", travel_id, type(travel_id))
    print("travel_details: ", travel_details,type(travel_details))
    print("reserved_booking: ", reserved_booking, type(reserved_booking))
    print("balance: ", balance, type(balance))
    print("coupons: ", coupons, type(coupons))
    print("pnr: ", pnr, type(pnr))
    print("seat_number: ", seat_number, type(seat_number))
    print("seat_chosen: ", seat_chosen, type(seat_chosen))
    print("is_logged_in: ", session["loggedin"], type(session["loggedin"]))
    print("user_id: ", user_id, type(user_id))
    print("coupon_id: ", coupon_id, type(coupon_id))
    #print("journeys: ", journeys, type(journeys))
    #print("journey_count: ", journey_count, type(journey_count))
    #print("journey_name:" , journey_name, type(journey_name))
    
    travel_details_list = list(travel_details)
    travel_details_list[3] = travel_details_list[3].strftime("%Y-%m-%d, %H:%M:%S")
    
    print("EMAIL: ", user_email)
    #sns_client = boto3.client('sns')
    #sns_client.publish(TopicArn="arn:aws:sns:us-east-1:637423226272:BuyTravel", Message="Hello motherfucker!", Subject="BuyTravel!!")
    """client = boto3.client("ses")
    message = {"Subject" : {"Data" : "THEGOD"}, "Body" : {"Html": {"Data": "BODİİİİİ"}}}
    response = client.send_email(Source="gelgitapp@gmail.com", Destination={"ToAddresses" : ["canbagirgan@gmail.com"]}, Message=message)"""
    #send_email()
    """sns_client = boto3.client('sns')
    topic_arn = 'arn:aws:sns:us-east-1:637423226272:BuyTravel'  # SNS konu ARN'si
    message = {'lambda_function': 'email'}  # Tetiklenecek Lambda fonksiyonun adı
    response = sns_client.publish(
        TopicArn=topic_arn,
        Message=json.dumps({'default': json.dumps(message)}),
        MessageStructure='json'
    )
    print(response)"""
    #url = 'https://34b7tnxk3e.execute-api.us-east-1.amazonaws.com/dev/email'
    #http = urllib3.PoolManager()
    #r = http.request('POST', url)
    return {
        'statusCode': 200,  # Customizing the status code
        'body' : {
    
            'message' : "Purchase Successful",  # Including custom message in the response body
            'travel_id' : travel_id,
            'travel_details' : travel_details_list,
            'reserved_booking' : reserved_booking,
            'balance' : balance,
            'coupons' : coupons,
            'pnr' : pnr,
            'seat_number' : seat_number,
            'seat_chosen' : seat_chosen,
            "is_logged_in" : session["loggedin"],
            'user_id' : user_id,
            'coupon_id' : coupon_id,
            'some_other_data': 'value',  # Including additional data
        }
    }
    

import json
import sys
import logging
import pymysql
import os

"""
The code creates the connection to your database outside of the handler function. 
Creating the connection in the initialization code allows the connection to be 
re-used by subsequent invocations of your function and improves performance. 
"""

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")


def lambda_handler(event, context):
    
    print('event: ', event)
    vehicle_type = event['body-json']['vehicle_type']
    departure_city = event['body-json']['from-location']
    arrival_city = event['body-json']['to-location']
    departure_date = event['body-json']['departure_date']
    extra_date = event['body-json']['extra_date']
    print("extra_date: ", extra_date)
    if extra_date == 'undefined':
        extra_date = None
    
    sort_type = 'T.depart_time'
    sort_in = 'earliest_to_latest'
    
    with conn.cursor() as cursor:
        if extra_date == None:
            print("SQL when extra_date none is executed")
            query = """
            SELECT C.id AS company_id, C.company_name, T.travel_id, T.depart_time, T.arrive_time, T.vehicle_type_id, T.price, T.business_price, Dep.name AS dep_terminal_name, Dep.city AS dep_city, Ar.name AS ar_terminal_name, Ar.city AS ar_city
            FROM Travel T
            JOIN Terminal Dep ON T.departure_terminal_id = Dep.terminal_id
            JOIN Terminal Ar ON T.arrival_terminal_id = Ar.terminal_id
            JOIN Vehicle_Type V ON V.id = T.vehicle_type_id
            JOIN Company C ON T.travel_company_id = C.id
            WHERE Dep.city = %s
            AND Ar.city = %s
            AND DATE(T.depart_time) = %s
            AND V.type = %s
            ORDER BY {}
            """.format(sort_type)
            cursor.execute(query, (departure_city, arrival_city, departure_date, vehicle_type))
            searchedTravels = cursor.fetchall()
        else:
            print("SQL when extra_date not-none is executed")
            query = """
            SELECT C.id AS company_id, C.company_name, T.travel_id, T.depart_time, T.arrive_time, T.vehicle_type_id, T.price, T.business_price, Dep.name AS dep_terminal_name, Dep.city AS dep_city, Ar.name AS ar_terminal_name, Ar.city AS ar_city
            FROM Travel T
            JOIN Terminal Dep ON T.departure_terminal_id = Dep.terminal_id
            JOIN Terminal Ar ON T.arrival_terminal_id = Ar.terminal_id
            JOIN Vehicle_Type V ON V.id = T.vehicle_type_id
            JOIN Company C ON T.travel_company_id = C.id
            WHERE Dep.city = %s
            AND Ar.city = %s
            AND DATE(T.depart_time) <= %s
            AND DATE(T.depart_time) >= %s
            AND V.type = %s
            ORDER BY {}
            """.format(sort_type)
            cursor.execute(query, (departure_city, arrival_city, extra_date, departure_date, vehicle_type))
            searchedTravels = cursor.fetchall()
        
        print('searchedTravels: ', searchedTravels)
        
        ## Unable to marshal response: Object of type datetime is not JSON serializable
        ## To overcome the error above, datetime data type should be changed
        searchedTravelsList = []
        for travel in searchedTravels:
            travel = list(travel) # converting tuple to list
            travel[3] = travel[3].isoformat()
            travel[4] = travel[4].isoformat()
            searchedTravelsList.append(travel)
        
        print("searchedTravels after datetime datatype changed:", searchedTravels)

    return {
        'statusCode': 200,
        'body': {
            "vehicle_type": vehicle_type,
            "departure_city": departure_city,
            "arrival_city": arrival_city,
            "departure_date": departure_date,
            "extra_date": extra_date,
            "sort_in": sort_in,
            "searchedTravels": searchedTravelsList
        }
    }
